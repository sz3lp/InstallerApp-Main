export const navLinks = [
  { path: '/', label: 'Home' },
  { path: '/appointments', label: 'Appointment Summary' },
  { path: '/activity', label: 'Activity Summary' },
  { path: '/ifi', label: 'IFI Dashboard' },
  { path: '/feedback', label: 'Feedback' },
  { path: '#', label: 'MyLearning - SentientZone' },
];
